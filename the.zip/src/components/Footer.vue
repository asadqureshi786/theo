<template>

    Footer

</template>

<script>
    export default {
        name : 'Footer',
    }
</script>