<template>
    <Header/>
    <div class="main_wrapper">
        <router-view></router-view>
    </div>
    <Footer/>
</template>

<script>
import Header from '@/components/Header.vue'
import Footer from '@/components/Footer.vue'
export default {
    name : "DefaultLayout",
    components : {
        Header,
        Footer
    }
}
</script>


<style >
    .main_wrapper{
        margin-top: 66px;
    }
</style>