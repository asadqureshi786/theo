import { createApp } from 'vue'
import App from './App.vue'
import 'primeicons/primeicons.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import '@/assets/style/style.css'
import route from './route'

createApp(App).use(route).mount('#app')
