<template>
    <h2>Agents</h2>
</template>

<script>
    export default {
        name : 'Agents'
    }
</script>