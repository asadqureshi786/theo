<template>
    <h2>Clubs</h2>
</template>

<script>
    export default {
        name : 'Clubs'
    }
</script>