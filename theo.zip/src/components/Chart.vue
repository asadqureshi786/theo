<template>
    My Chart Text
</template>

<script>
    export default {
        name : 'Chart'
    }
</script>