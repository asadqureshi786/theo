<template>
    <div class="banner">
        <h1 class="hd" >The Ultimate Platform for Professional Football Agents</h1>
        <div class="content">
            <p class="text" >From scouting talent and managing contracts to building club relationships it’s all here!</p>
            <p class="text" >A modern digital workspace built exclusively for licensed agents.</p>
        </div>
        <button class="btn btn-simple" >Get Started</button>
    </div>
</template>

<script>
    export default {
        name : 'Banner',
    }
</script>
